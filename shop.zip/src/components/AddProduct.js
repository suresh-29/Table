import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { toast } from "react-toastify";
import { useHistory } from "react-router-dom";

const AddProduct = () => {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [weight, setWeight] = useState("");

  const products = useSelector((state) => state.ProductReducer);
  const dispatch = useDispatch();
  const history = useHistory();

  console.log(products);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!price || !name || !weight) {
      return toast.warning("Please Fill In all The fields");
    }

    const data = {
      id: products[products.length - 1].id + 1,
      name,
      price,
      weight
    };

    console.log(data);
    dispatch({
      type: "ADD_PRODUCT",
      payload: data
    });
    toast.success(" New Product Entered successfully");
    history.push("/");
  };
  return (
    <div className="container">
      <h1 className="display-3 my-5 text-center ">Add Product</h1>
      <div className="row">
        <div className="col-md-6  shadow mx-auto p-5">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <input
                type="text"
                placeholder="Name"
                className="form-control"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="form-group">
              <input
                type="number"
                placeholder="Price"
                className="form-control"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
              />
            </div>
            <div className="form-group">
              <input
                type="number"
                placeholder="Weight"
                className="form-control"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
              />
            </div>
            <div className="form-group">
              <input
                type="submit"
                value="Add Product"
                className="btn btn-block btn-dark"
              />
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddProduct;
