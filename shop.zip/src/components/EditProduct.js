import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useHistory, useParams } from "react-router-dom";
import { toast } from "react-toastify";

const EditProduct = () => {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [weight, setWeight] = useState("");

  const dispatch = useDispatch();
  const history = useHistory();

  const { id } = useParams();
  const products = useSelector((state) => state.ProductReducer);

  const currentProduct = products.find(
    (product) => product.id === parseInt(id)
  );

  useEffect(() => {
    if (currentProduct) {
      setName(currentProduct.name);
      setPrice(currentProduct.price);
      setWeight(currentProduct.weight);
    }
  }, [currentProduct]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!price || !name || !weight) {
      return toast.warning("Please Fill In all The fields");
    }

    const data = {
      id: parseInt(id),
      name,
      price,
      weight
    };

    console.log(data);
    dispatch({
      type: "UPDATE_PRODUCT",
      payload: data
    });
    toast.success(" Product Data Updated successfully");
    history.push("/");
  };

  return (
    <div className="container">
      {currentProduct ? (
        <>
          <h1 className="display-3 my-5 text-center ">Edit Product {id}</h1>
          <div className="row">
            <div className="col-md-6  shadow mx-auto p-5">
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <input
                    type="text"
                    placeholder="Name"
                    className="form-control"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <input
                    type="number"
                    placeholder="Price"
                    className="form-control"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <input
                    type="number"
                    placeholder="Weight"
                    className="form-control"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <input
                    type="submit"
                    value="Update Product"
                    className="btn  btn-dark update_button"
                  />
                  <Link to="/" className="btn btn-danger  ml-3">
                    Cancel
                  </Link>
                </div>
              </form>
            </div>
          </div>
        </>
      ) : (
        <h1 className="display-3 my-5 text-center">
          Product with {id} Doesnot Exist{" "}
        </h1>
      )}
    </div>
  );
};

export default EditProduct;
