import React, { useState } from "react";
import { useGlobalFilter } from "react-table";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";

function Home() {
  const products = useSelector((state) => state.ProductReducer);
  const dispatch = useDispatch();
  const [searchTerm, setSearchTerm] = useState("");
  const deleteProduct = (id) => {
    dispatch({
      type: "DELETE_PRODUCT",
      payload: id
    });
    toast.success("Product Deleted Successfully!..");
  };
  return (
    <div className="container">
      <div className="row">
        <div className="col-md-4 my-5 text-right ">
          <Link to="/add" className="btn btn-outline-dark">
            Add Products
          </Link>
        </div>
        <div className="col-md-4 my-5 text-right ">
          <input
            className="form-control"
            type="text"
            placeholder="Search Products ..."
            onChange={(event) => {
              setSearchTerm(event.target.value);
            }}
          />
        </div>
        <div className="col-md-12 mx-auto">
          <table className="table table-hover">
            <thead className="text-white bg-dark text-center">
              <tr>
                <th scope="col">S.no</th>
                <th scope="col">Product</th>
                <th scope="col">Price ₹</th>
                <th scope="col">Weight (g)</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
              </tr>
            </thead>
            <tbody>
              {products.length !== 0 &&
                products.map((product, id) => (
                  <tr key={id}>
                    <td>{id + 1}</td>
                    <td>{product.name}</td>
                    <td>{product.price}</td>
                    <td>{product.weight}</td>
                    <td>
                      <Link
                        to={`/edit/${product.id}`}
                        className="btn btn-small btn-primary mr=2"
                      >
                        Edit
                      </Link>
                    </td>
                    <td>
                      <button
                        to={`/edit/${product.id}`}
                        type="button"
                        onClick={() => deleteProduct(product.id)}
                        className="btn btn-small btn-danger mr=2"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Home;
