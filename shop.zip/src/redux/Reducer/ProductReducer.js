const initialState = [
  {
    id: 0,
    name: "Chilli Powder",
    price: 100,
    weight: 50
  },
  {
    id: 1,
    name: "Chicken Masala",
    price: 50,
    weight: 100
  },
  {
    id: 2,
    name: "Fish Curry Masala",
    price: 20,
    weight: 50
  },
  {
    id: 3,
    name: "Mutton Masala",
    price: 60,
    weight: 100
  },
  {
    id: 4,
    name: "Tamarind Rice Powder",
    price: 70,
    weight: 100
  },
  {
    id: 5,
    name: "Garlic Rice Powder",
    price: 100,
    weight: 50
  },
  {
    id: 6,
    name: "Turmeric Powder",
    price: 50,
    weight: 250
  },
  {
    id: 7,
    name: "Coriander Powder",
    price: 100,
    weight: 50
  }
];

const ProductReducer = (state = initialState, action) => {
  switch (action.type) {
    case "ADD_PRODUCT":
      state = [...state, action.payload];
      return state;
    case "UPDATE_PRODUCT":
      const updateState = state.map((product) =>
        product.id === action.payload.id ? action.payload : product
      );
      state = updateState;
      return state;
    case "DELETE_PRODUCT":
      const filterProduct = state.filter(
        (product) => product.id !== action.payload && product
      );
      state = filterProduct;
      return state;
    default:
      return state;
  }
};
export default ProductReducer;
