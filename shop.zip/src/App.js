import './App.css';
import { ToastContainer } from "react-toastify";
import NavBar from './components/NavBar';
import { Switch, Route } from "react-router-dom";
import Home from './components/Home';
import AddProduct from './components/AddProduct';
import EditProduct from './components/EditProduct';


function App() {
  return (
    <div className="App">
      <ToastContainer />
      <NavBar />
      <Switch>
        <Route exact path="/" component={Home} />
        <Route path="/add" component={AddProduct} />
        <Route path="/edit/:id" component={EditProduct} />
      </Switch>
    </div>
  );
}

export default App;
